
import React from 'react';

export default function Logbook() {
  return (
    <div className="dashboard">
      <h2>Logbook</h2>
      <div className="card">Week 1 Entry</div>
      <div className="card">Week 2 Entry</div>
      <div className="card">Week 3 Entry</div>
    </div>
  );
}

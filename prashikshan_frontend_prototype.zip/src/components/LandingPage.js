
import React from 'react';
import { useNavigate } from 'react-router-dom';

export default function LandingPage() {
  const navigate = useNavigate();
  return (
    <div className="container">
      <h1>Prashikshan</h1>
      <p>Bridging Students, Colleges & Industries for NEP Internships</p>
      <button onClick={() => navigate('/select-role')} className="btn">Register</button>
    </div>
  );
}


import React from 'react';

export default function StudentDashboard() {
  return (
    <div className="dashboard student">
      <h2>Student Dashboard</h2>
      <div className="card">Internship Search Filters</div>
      <div className="card">Application Timeline</div>
      <div className="card">Logbook Tracker</div>
      <div className="card">Pre-Internship Training</div>
    </div>
  );
}


import React from 'react';

export default function CollegeDashboard() {
  return (
    <div className="dashboard college">
      <h2>College Dashboard</h2>
      <div className="card">Mentor Assignment</div>
      <div className="card">Credit Approval</div>
      <div className="card">Student Progress Dashboard</div>
      <div className="card">Generate Certificates</div>
    </div>
  );
}

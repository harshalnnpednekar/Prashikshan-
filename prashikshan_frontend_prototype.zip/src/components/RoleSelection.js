
import React from 'react';
import { useNavigate } from 'react-router-dom';

export default function RoleSelection() {
  const navigate = useNavigate();
  return (
    <div className="container">
      <h2>Select Role</h2>
      <button onClick={() => navigate('/student')} className="btn student">Student</button>
      <button onClick={() => navigate('/college')} className="btn college">College</button>
      <button onClick={() => navigate('/industry')} className="btn industry">Industry</button>
    </div>
  );
}

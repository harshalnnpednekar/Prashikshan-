
import React from 'react';

export default function IndustryDashboard() {
  return (
    <div className="dashboard industry">
      <h2>Industry Dashboard</h2>
      <div className="card">Post Openings</div>
      <div className="card">Manage Applicants</div>
      <div className="card">Issue Certificates</div>
    </div>
  );
}

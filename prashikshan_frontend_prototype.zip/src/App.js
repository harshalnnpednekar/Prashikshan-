
import React from 'react';
import { Routes, Route } from 'react-router-dom';
import LandingPage from './components/LandingPage';
import RoleSelection from './components/RoleSelection';
import StudentDashboard from './components/StudentDashboard';
import CollegeDashboard from './components/CollegeDashboard';
import IndustryDashboard from './components/IndustryDashboard';
import Logbook from './components/Logbook';
import Navbar from './components/Navbar';

export default function App() {
  return (
    <div>
      <Navbar />
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/select-role" element={<RoleSelection />} />
        <Route path="/student" element={<StudentDashboard />} />
        <Route path="/college" element={<CollegeDashboard />} />
        <Route path="/industry" element={<IndustryDashboard />} />
        <Route path="/logbook" element={<Logbook />} />
      </Routes>
    </div>
  );
}
